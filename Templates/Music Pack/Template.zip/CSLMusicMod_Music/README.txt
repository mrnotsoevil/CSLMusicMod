==========================
Add music files
==========================

Here you can add music files like adding your songs manually into steamapps/common/Cities_Skylines/CSLMusicMod_Music.

Please see the documentation (https://github.com/rumangerst/CSLMusicMod/blob/master/README.md) for more information about the supported file types.