=========================
Creating a music pack
=========================

How to create a music pack for CSL Music Mod http://steamcommunity.com/sharedfiles/filedetails/?id=422934383

1. Go to Source folder and open Mod.cs
2. Replace <MyMusicPack_Techname> by the name of your pack (This must not contain any spaces)

    Example: Epic_Soundtrack

3. Replace <My Music Pack> by the "real" name of your pack (This one can contain spaces)

    Example: Epic Soundtrack
    
4. Replace <YourUser> by your user name
    
5. Put your music files into the CSLMusicMod_Music folder. See README.txt in this folder for additional information.


Note: Your music pack must follow the Steam Workshop agreements (https://steamcommunity.com/workshop/workshoplegalagreement/).
I am not responsible if you upload something and you get into trouble!